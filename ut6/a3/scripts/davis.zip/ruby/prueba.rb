#!/usr/bin/env ruby 

11.times do |i|
    system("id ayoze#{i}")
end
